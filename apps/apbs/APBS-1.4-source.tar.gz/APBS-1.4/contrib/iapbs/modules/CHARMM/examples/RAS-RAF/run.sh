#!/bin/sh


charmm=../../../../../c35b2/exec/gnu/charmm

$charmm < ligand-mod.inp |tee ligand-mod.log

